package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication//表示该类为启动类


/*@Controller + @ResponseBody;
 * 将当前修饰的类注入SpringBoot IOC容器，使得从该类所在的项目跑起来的过程中，这个类就被实例化;
 * 将函数返回值以Jason字符串的形式返回给客户端
 * */
@RestController
public class DemoApplication {

	public static void main(String[] args) {
		//启动主线程
		//SpringApplication.run(DemoApplication.class, args);//参数:DemoApplication类对象
		SpringApplication.run(DemoApplication.class);
	}

	
	@GetMapping("/hello")//将HTTP Get 映射到 特定的处理方法上,Http有get和post两种请求方式
	//@RequestParam用来映射请求参数，value为接手前台参数的参数名，defaultValue为请求参数的默认值
	public String hello(@RequestParam(value="name",defaultValue="World") String name)
	{
		return String.format("Hello %s",name);//format(),格式化字符串
	}
}
